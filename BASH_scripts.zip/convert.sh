#!/bin/bash

#SBATCH --cpus-per-task=8
#SBATCH --time=5:00:00
#SBATCH --mem=16GB
#SBATCH --array=0-11
#SBATCH --job-name=conversion
#SBATCH --output=conversion_slurm_%j.out

##########

# SBATCH Code accepts 1 SAM file per run
# Converts the SAM file to BAM file
# Sorts the BAM files in coordinate order
# Builds an index for each BAM file

#########

module purge
module load picard/2.23.8

# Creating the array
file_sort_arr=(*sam)

# Converting SAM >> BAM files and sorting
java -jar $PICARD_JAR SortSam \
INPUT=${file_sort_arr[$SLURM_ARRAY_TASK_ID]} \
OUTPUT=${file_sort_arr[$SLURM_ARRAY_TASK_ID]::-4}.bam \
SORT_ORDER=coordinate

# Indexing the sorted BAM files
java -jar picard.jar BuildBamIndex \
INPUT=OUTPUT=${file_sort_arr[$SLURM_ARRAY_TASK_ID]::-4}.bam
