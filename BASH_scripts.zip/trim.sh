#!/bin/bash

#SBATCH --cpus-per-task=8
#SBATCH --time=5:00:00
#SBATCH --mem=16GB
#SBATCH --array=0-11
#SBATCH --job-name=trim
#SBATCH --output=trim_slurm_%j.out

##########

# SBATCH Code accepts #two PE (Paired End)# fastq file.
# Output will  be 4 other fastq file with forward/ reverse, paired/unpaired
# From fastqc analysis, the following sequence lengths were observed for read 1: 14 nucleotides and read 2: 51 nucleotides
# Given the length of read 1, the minimum length for trimming was set to 10 nucleotides.
#########

module purge
module load trimmomatic/0.39

# Creating the array for the SRR numbers
file_arr=(76 77 78 79 80 81 82 83 84 85 86 87)

# Call Trimmomatic module for trim
java -jar $TRIMMOMATIC_JAR PE -threads 8 -phred33 SRR90791${file_arr[$SLURM_ARRAY_TASK_ID]}_1.fastq SRR90791${file_arr[$SLURM_ARRAY_TASK_ID]}_2.fastq \
SRR90791${file_arr[$SLURM_ARRAY_TASK_ID]}_forward_paired.fastq SRR90791${file_arr[$SLURM_ARRAY_TASK_ID]}_forward_unpaired.fastq \
SRR90791${file_arr[$SLURM_ARRAY_TASK_ID]}_reverse_paired.fastq SRR90791${file_arr[$SLURM_ARRAY_TASK_ID]}_reverse_unpaired.fastq \
ILLUMINACLIP:$TRIMMOMATIC_ROOT/adapters/TruSeq3-PE.fa:2:30:10 \
LEADING:3 TRAILING:3 SLIDINGWINDOW:4:20 MINLEN:10
