#!/bin/bash

#SBATCH --cpus-per-task=8
#SBATCH --time=5:00:00
#SBATCH --mem=16GB
#SBATCH --array=0-11
#SBATCH --job-name=count
#SBATCH --output=count_slurm_%j.out

##########

# SBATCH Code accepts 1 BAM file per run
# Creates a count matrix using the aligned bam file and features gtf file
# -m option is intersection non-empty
# Since the reads are paired end, the -r option is set to pos to indicate that the reads were sorted by alignment position
# Specify -type exon to get gene counts
# $1: Features gtf file: GRCh38.gtf
# Make count file into txt for downstream R analysis
# idattr:

#########

module purge
module load htseq/0.13.5

# Creating the array for the SRR numbers
file_arr=(76 77 78 79 80 81 82 83 84 85 86 87)

# Creating the count matrix
htseq-count -m intersection-nonempty -t exon -r pos --idattr ID SRR90791${file_arr[$SLURM_ARRAY_TASK_ID]}.bam $1 > SRR${file_arr[$SLURM_ARRAY_TASK_ID]}.count
