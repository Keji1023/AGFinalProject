#!/bin/bash

#SBATCH --cpus-per-task=8
#SBATCH --time=5:00:00
#SBATCH --mem=16GB
#SBATCH --array=0-11
#SBATCH --job-name=inspection
#SBATCH --output=inspection_slurm_%j.out

##########

# SBATCH Code analyzes the quality of the alignment performed.

#########

module purge
module load samtools/intel/1.14

# Creating the array
file_arr=(*sam)

# To inspect the output of the alignment
samtools flagstat ${file_arr[$SLURM_ARRAY_TASK_ID]}
