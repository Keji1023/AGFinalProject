#!/bin/bash

#SBATCH --cpus-per-task=16
#SBATCH --time=24:00:00
#SBATCH --mem=48GB
#SBATCH --array=0-11
#SBATCH --job-name=Star_align
#SBATCH --output=star_alignment_slurm_%j.out

##########

# SBATCH Code accepts two paired end files: forward (1) and reverse (2)

# BUILDING THE REFERENCE GENOME
# --runThread: Number of threads (processors) for mapping reads to a genome
# --runmode: run mode for STAR. genomeGenerate mode builds genome index
# $1 = path to the directory (genomeDir) where the reference genome index will be stored: human_genome_index
# $2 = reference genome file in FASTA format (genomeFastaFiles): GRCh38_latest_genomic.fna
# $3 = GTF file for gene annotation (sjdbGTFfile): GRCh38_latest_genomic.gff
# --sjdbGTFtagExonParentTranscript: for defining the parent-child relationship when using GFF instead of GTF file
# --sjdbOverhang: length of reads around the splice junctions. The ideal values should be max(read length)-1: 50

# MAPPING THE READS TO THE GENOME
# --readFilesIn: read files for mapping to the genome
# --outSAMtype: output coordinate sorted BAM file 
# --outFileNamePrefix: provide output file prefix name
# --outputSAMunmapped: output unmapped reads from the main SAM file in SAM format.

#########

# Setting up the module environment
module purge
module load gcc/10.2.0 
module load star/intel/2.7.6a

# To build the reference genome index using the GFF3 file
STAR --runThreadN 12 \
--runMode genomeGenerate \
--genomeDir $1 \
--genomeFastaFiles $2 \
--sjdbGTFfile $3 \
--sjdbGTFtagExonParentTranscript Parent \
--sjdbOverhang 50

# Creating the array for the SRR numbers
file_arr=(76 77 78 79 80 81 82 83 84 85 86 87)

# To map the trimmed paired end file to the genome
STAR --runThreadN 12 \
--readFilesIn SRR90791${file_arr[$SLURM_ARRAY_TASK_ID]}_forward_paired.fastq SRR90791${file_arr[$SLURM_ARRAY_TASK_ID]}_reverse_paired.fastq \
--genomeDir $1 \
--outSAMtype BAM SortedByCoordinate \
--outFileNamePrefix SRR90791${file_arr[$SLURM_ARRAY_TASK_ID]}  \
--outSAMunmapped Within
