#!/bin/bash

#SBATCH --cpus-per-task=8
#SBATCH --time=5:00:00
#SBATCH --mem=16GB
#SBATCH --array=0-11
#SBATCH --job-name=Align
#SBATCH --output=alignment_slurm_%j.out

##########

# SBATCH Code accepts two paired end files: forward (1) and reverse (2)
# $1 = reference genome: GRCh38_latest_genomic.fna
# $2 = index prefix: h_sapiens

#########

module purge
module load hisat2/2.2.1

# To build the reference genome index
hisat2-build $1 $2

# Creating the array for the SRR numbers
file_arr=(76 77 78 79 80 81 82 83 84 85 86 87)

# To run alignment on the trimmed file
hisat2 -x $2 -1 SRR90791${file_arr[$SLURM_ARRAY_TASK_ID]}_forward_paired.fastq -2 SRR90791${file_arr[$SLURM_ARRAY_TASK_ID]}_reverse_paired.fastq \
-S SRR90791${file_arr[$SLURM_ARRAY_TASK_ID]}.sam
