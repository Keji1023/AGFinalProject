#!/bin/bash

#SBATCH --cpus-per-task=8
#SBATCH --time=5:00:00
#SBATCH --mem=16GB
#SBATCH --array=0-11
#SBATCH --job-name=import
#SBATCH --output=import_slurm_%j.out

##########

# array contains list of numbers corresponsing to the last figures in SRR numbers of samples
# split-3 opition to split spots into biological reads.

#########

module load sra-tools/2.10.9
module load fastqc/0.11.9

# Creating the array for the SRR numbers
file_arr=(76 77 78 79 80 81 82 83 84 85 86 87)
echo ${file_arr[1]}

# To get fastq files and change permissions
fasterq-dump SRR90791${file_arr[$SLURM_ARRAY_TASK_ID]} --split-3
chmod 777 *fastq

# To perform fastqc analysis
fastqc SRR90791${file_arr[$SLURM_ARRAY_TASK_ID]}_1.fastq
fastqc SRR90791${file_arr[$SLURM_ARRAY_TASK_ID]}_2.fastq