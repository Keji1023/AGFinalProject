#!/bin/bash

#SBATCH --cpus-per-task=8
#SBATCH --time=5:00:00
#SBATCH --mem=16GB
#SBATCH --array=0-11
#SBATCH --job-name=inspect_trimming
#SBATCH --output=inspect_trimming_fastq_slurm_%j.out

##########

# This script performs fastqc analysis on the trimmed paired fastq files.

#########

module load fastqc/0.11.9

# Creating the array for the SRR numbers
file_arr=(76 77 78 79 80 81 82 83 84 85 86 87)
echo ${file_arr[1]}

# To perform fastqc analysis
fastqc SRR90791${file_arr[$SLURM_ARRAY_TASK_ID]}_forward_paired.fastq
fastqc SRR90791${file_arr[$SLURM_ARRAY_TASK_ID]}_reverse_paired.fastq
